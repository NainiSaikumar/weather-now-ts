import './App.css'

// Replace your code here
const App = () => <h1>Hello World</h1>

export default App
